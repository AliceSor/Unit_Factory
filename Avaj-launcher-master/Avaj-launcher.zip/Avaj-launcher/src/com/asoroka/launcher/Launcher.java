package com.asoroka.launcher;

import java.io.*;
import com.asoroka.launcher.Coordinates;
import com.asoroka.launcher.airtransport.Aircraft;
import com.asoroka.launcher.airtransport.Flyable;
import com.asoroka.launcher.Tower;

import com.asoroka.launcher.airtransport.Baloon;
import com.asoroka.launcher.airtransport.JetPlane;
import com.asoroka.launcher.airtransport.Helicopter;

public class Launcher
{
	public static void main(String[] args)
	{
		Coordinates coord;
		
		coord = new Coordinates(1, 2, 2);
		System.out.println("start");
		System.out.println(coord.getLongitude());
	}
}
