package com.asoroka.launcher;

import java.io.*;
import com.asoroka.launcher.Coordinates;
import com.asoroka.launcher.WeatherProvider;

public class WeatherTower extends Tower
{
	public String getWeather(Coordinates coordinates)
	{
		return (WeatherProvider.getWeather());
		String res = new String("");
		return (res);
	}

	void changeWeather()
	{
		this.conditionsChanged();
	}

}