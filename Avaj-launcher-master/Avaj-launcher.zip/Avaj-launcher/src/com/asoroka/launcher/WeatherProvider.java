package com.asoroka.launcher;

import java.io.*;
import com.asoroka.Coordinates;

class WeatherProvider
{
	WeatherProvider weatherProvider;
	String[] weather;

	WeatherProvider()
	{

	}

	public WeatherProvider getProvider()
	{

	}

	public String getCurrentWeather(Coordinates coordinates)
	{

	}
}