package com.asoroka.launcher.airtransport;

import com.asoroka.launcher.WeatherTower;

public interface Flyable
{
	public void updateConditions();
	public void registerTower(WeatherTower weatherTower);
}
