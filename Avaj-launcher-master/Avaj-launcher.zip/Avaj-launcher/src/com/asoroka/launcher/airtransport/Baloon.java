package com.asoroka.launcher.airtransprot;

import java.io.*;
import com.asoroka.launcher.WeatherTower;
import com.asoroka.launcher.Coordinates;

class Baloon extends Aircraft implements Flyable 
{
	WeatherTower weatherTower;

	Helicopter(String name, Coordinates coordinates)
	{

	}

	void updateConditions()
	{

	}

	void registerTower(WeatherTower weatherTower)
	{

	}
}